﻿using Microsoft.SqlServer.Server;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Dizionario
{
    public partial class Form1 : Form
    {

        Albero alberello = new Albero();                                                //Creo il mio albero
        Nodo nodo;                                                                      //Creo una variabile visibile in tutta la classe form1 in modo da poterla usare in tutte
                                                                                        //      le funzioni senza doveer richiamare più volte il metodo "cerca" riducendo i processi
        bool italiano = true;                                                           //creo una variabile globae per capire se il io dizionario è attualmente in lingua italiana o
                                                                                        //      inglese
        int tag = 0;                                                                    //creo una variabile tag globale in modo da poter gestire tutte le verie label delle
                                                                                        //definizioni

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            if (File.Exists("Dizionario.txt"))                                          //Verifico l'esistenza del file di testo dove dovrebbero essere savate tutte e mie parole e definizioni
            {
                using (FileStream fs = new FileStream("Dizionario.txt", FileMode.Open)) //utilizzo uno "using" per creare il mio filestream in modo da ottimizzare le prestazioni e non dover
                {                                                                       //      fare il dismiss
                    List<String> stringhe = new List<string>();                         //creo una lista di stringhe dove andrò a memorizzare tutte le righe del mio file
                    stringhe.AddRange(File.ReadAllLines("Dizionario.txt"));             //Aggiungo le stringhe del mio file nella mia lista di stringhe
                    foreach (String s in stringhe)                                      //ripeto per ogni stringa
                    {
                        string[] split = s.Split('#');                                  //Separo la stringa per il carattere predefinito di separazione
                        Nodo app = new Nodo(split[0], true);                            //Creo un nuovo nodo definendo la sezione, che sarà appunto la prima parte della mia stringa, e il fatto che sia un parola e
                                                                                        //non un nodo fittizio
                        for (int i = 1; i < split.Length; i++)                          //Ripeto per tutte le definizioni
                            app.AggiungiDefinizione(split[i]);                          //Aggiungo una definizione
                        alberello.AggiungineUno(app);                                   //Aggiungo il nodo appena riempito al mio albero
                    }
                }
            }
            else                                                                        //nel caso il file di testo non esista o si sia per qualche assurdo motivo eliminato utilizzo
            {                                                                           //      il file binario, esso ha lo stesso contenuto del file di testo
                using (FileStream fs = new FileStream("Dizionario.bin", FileMode.OpenOrCreate))//Verifico che il file esista oppure, nel caso anche esso non esistesse, lo creo
                {
                    BinaryReader br = new BinaryReader(fs);                             //creo il lettore del mio file binario
                    List<String> stringhe = new List<string>();                         //eseguo lo stesso processo del file di testo ma tenendo conto che è un file binario
                    while (fs.Seek(0, SeekOrigin.Current) != fs.Seek(0, SeekOrigin.End))
                    {
                        stringhe.Add(br.ReadString());
                    }
                    foreach(String s in stringhe)
                    {
                        string[] split = s.Split('#');
                        Nodo app = new Nodo(split[0], true);
                        for (int i = 1; i < split.Length; i++)
                            app.AggiungiDefinizione(split[i]);
                        alberello.AggiungineUno(app);
                    }
                }
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e) //tasto cerca menu pincipale -----------------------------------------------------------------------------------------
        {
            if(textBox1.Text.Trim() != "")                                              //verifico che il contenuto della casella di ricerca sia valido
            {
                nodo = alberello.Cerca(textBox1.Text);                                  //cerco nel mio albero il la parola richiesta
                if (!nodo.Parola)                                                       //verifico che la parola richiesta sia stata trovata
                {
                    MessageBox.Show("La parola richiesta non esiste tra quelle " +      //restituisco un messaggio di errore nel caso la parola non esista
                        "da te definite, inserisci una nuova parola ed attribuiscile " +
                        "un significato perchè possa essere trovata");
                    return;                                                             //interrompo l'esecuzione
                }
            }
            else
            {
                MessageBox.Show("Devi scrivere qualcosa prima di premere cerca");       //restituisco un messaggio di errore nel caso lo spazio di ricerca sia vuoto
                return;                                                                 //interrompo l'esecuzione
            }
            panel1.Visible = true;                                                      //faccio apparire il pannello dove vengono mostrate la parola e le sue definizioni
            label3.Text = nodo.Sezione;                                                 //sostituisco il testo attualmente presente in alto al centro con la parola cercata
            label4.Text = nodo.Definizioni[0];                                          //faccio comparire nello spazio sottostante la prima definizione disponibile per la parola
            textBox1.Text = "";                                                         //svuoto il contenuto della textbox
        }//--------------------------------------------------------------------------------------------------------------------------------------------------------------------------

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e) //tasto traduci in italiano nel menù principale ----------------------------------------------------------------------
        {
            if (!italiano)                                                              //controllo se l'albero è attualmente in inglese
            {
                invertiAlbero();                                                        //inverto le lingue
                button2.BackColor = Color.Gainsboro;                                    //coloro il pulsante premuto
                button3.BackColor = Color.White;                                        //resetto al colore di default
            }
            else
                MessageBox.Show("Il traduttore permette già di ricercare " +            //invio un avvertimento nel caso l'albero fosse già in italiano
                    "parole italiane");
        }//--------------------------------------------------------------------------------------------------------------------------------------------------------------------------
        
        private void button3_Click(object sender, EventArgs e) //tasto traduci in inglese nel menù principale -----------------------------------------------------------------------
        {
            if (italiano)                                                              //controllo se l'albero è attualmente in italiano
            {
                invertiAlbero();                                                        //inverto le lingue
                button2.BackColor = Color.White;                                        //resetto al colore di default
                button3.BackColor = Color.Gainsboro;                                    //coloro il pulsante premuto
            }
            else
                MessageBox.Show("Il traduttore permette già di ricercare " +            //invio un avvertimento nel caso l'albero fosse già in inglese
                    "parole inglesi");
        }//--------------------------------------------------------------------------------------------------------------------------------------------------------------------------
        private void button21_Click(object sender, EventArgs e) //bottone aggiungi parola menù principale----------------------------------------------------------------------------
        {
            panel3.Visible = true;
        }//--------------------------------------------------------------------------------------------------------------------------------------------------------------------------

        public void invertiAlbero()
        {
            List<Nodo> nodini = Albero.TuttiFuori(alberello);                       //tiro fuori tutti nodi parola dal mio albero
            List<Nodo> nuovi = new List<Nodo>();                                    //creo una nuova lista all'interno della quale memorizzo tutti i nuovi nodi tradotti
            foreach (Nodo n in nodini)
            {
                foreach (String s in n.Definizioni)
                {
                    nuovi.Add(new Nodo(s, true));                                   //salvo un nuovo nodo tra i nodi tradotti che ha come sezione una definizione dei nodi
                                                                                    //      precedenti
                }                                                                   //ripeto per tutte le definizioni
            }                                                                       //ripeto per tutti i nodi che erano presenti nell'albero
            nuovi.Distinct();                                                       //elimino tutti i doppioni che si sono andati a creare
            foreach (Nodo no in nuovi)
            {
                foreach (Nodo n in nodini)
                {
                    foreach (String s in n.Definizioni)
                    {
                        if (no.Sezione == s)                                        //controllo se la sezione del nodo tradotto è uguale alla definizione di un vecchio nodo
                            no.Definizioni.Add(n.Sezione);                          //Aggiungo come definizione la sezione del vecchio nodo
                    }                                                               //ripeto per ogni definizione
                }                                                                   //ripeto per ogni vecchio nodo
            }                                                                       //ripeto per ogni nuovo nodo
            alberello.CreaAlbero(nuovi.ToArray());                                  //ricreo l'albero nell'altra lingua
        }

        private void button7_Click(object sender, EventArgs e) //bottone per scorrere le definizioni avanti nel primo pannello-------------------------------------------------------
        {
            tag++;
            if (tag >= nodo.Definizioni.Count)
                tag = 0;
            label4.Text = nodo.Definizioni[tag];
        }//--------------------------------------------------------------------------------------------------------------------------------------------------------------------------

        private void button6_Click(object sender, EventArgs e) //bottone per scorrere le definizioni indietro nel primo pannello-----------------------------------------------------
        {
            tag--;
            if (tag < 0)
                tag = nodo.Definizioni.Count - 1;
            label4.Text = nodo.Definizioni[tag];
        }//--------------------------------------------------------------------------------------------------------------------------------------------------------------------------

        private void button5_Click(object sender, EventArgs e) //bottone per tornare al menù principale nel primo pannello-----------------------------------------------------------
        {
            panel1.Visible = false;
        }//--------------------------------------------------------------------------------------------------------------------------------------------------------------------------

        private void button4_Click(object sender, EventArgs e) //bottone per caricare una nuova parola nel primo pannello------------------------------------------------------------
        {
            tag = 0;                                                                    //riporto il tag a 0
            if (textBox2.Text.Trim() != "")                                             //verifico che il contenuto della casella di ricerca sia valido
            {
                nodo = alberello.Cerca(textBox2.Text);                                  //cerco nel mio albero il la parola richiesta
                if (!nodo.Parola)                                                       //verifico che la parola richiesta sia stata trovata
                {
                    MessageBox.Show("La parola richiesta non esiste tra quelle " +      //restituisco un messaggio di errore nel caso la parola non esista
                        "da te definite, inserisci una nuova parola ed attribuiscile " +
                        "un significato perchè possa essere trovata");
                    return;                                                             //interrompo l'esecuzione
                }
            }
            else
            {
                MessageBox.Show("Devi scrivere qualcosa prima di premere cerca");       //restituisco un messaggio di errore nel caso lo spazio di ricerca sia vuoto
                return;                                                                 //interrompo l'esecuzione
            }
            label3.Text = nodo.Sezione;                                                 //sostituisco il testo attualmente presente in alto al centro con la parola cercata
            label4.Text = nodo.Definizioni[0];                                          //Faccio comparire nello spazio sottostante la prima definizione disponibile per la parola
        }//--------------------------------------------------------------------------------------------------------------------------------------------------------------------------

        private void button8_Click(object sender, EventArgs e) //Bottone per modificare le traduzioni nel primo pannello-------------------------------------------------------------
        {
            panel2.Visible = true;                                                      //rendo visibile il pannello rguardante la modifica delle definizioni
            label6.Text = nodo.Sezione;                                                 //metto in alto la sezione della mia parola
            tag = 0;                                                                    //pongo il tag delle definizioni a 0 (inizio)
            textBox3.Text = nodo.Definizioni[0];                                        //proprongo la prima definizione
        }//--------------------------------------------------------------------------------------------------------------------------------------------------------------------------

        private void button10_Click(object sender, EventArgs e) //bottone per scorrere in avanti le definizioni----------------------------------------------------------------------
        {
            tag++;                                                                      //aumento il tag della traduzione
            if (tag == nodo.Definizioni.Count)                                          //verifico se il tag è più alto del numero di definizioni della parola
            {
                textBox3.Text = "";                                                     //svuoto la casella di testo per attendere una nuova definizione
                return;                                                                 //interrompo l'esecuzione della funzione
            }
            else if (tag > nodo.Definizioni.Count)                                      //verifico se il tag è troppo alto
                tag = 0;                                                                //faccio ripartire le definizioni dall'inizio
            textBox3.Text = nodo.Definizioni[tag];                                      //riempio la textbox con la definizione inerente al tag
        }//--------------------------------------------------------------------------------------------------------------------------------------------------------------------------

        private void button11_Click(object sender, EventArgs e) //bottone per scorrere in indietro le definizioni--------------------------------------------------------------------
        {
            tag--;                                                                      //diminuisco il tag della traduzione
            if (tag == -1)                                                              //verifico se il tag è più basso di 0
            {
                textBox3.Text = "";                                                     //svuoto la casella di testo per attendere una nuova definizione
                button13.Visible = true;                                                //rendo visibile il bottone per poter salvare una nuova definizione
                return;                                                                 //interrompo l'esecuzione della funzione
            }
            else if (tag > -1)                                                          //verifico se il tag è troppo basso
                tag = nodo.Definizioni.Count-1;                                         //faccio ripartire le definizioni dall'ultima
            textBox3.Text = nodo.Definizioni[tag];                                      //riempio la textbox con la definizione inerente al tag
            button13.Visible = false;                                                   //rendo invisibile il bottone per poter salvare una nuova definizione
        }//--------------------------------------------------------------------------------------------------------------------------------------------------------------------------

        private void button9_Click(object sender, EventArgs e) //bottone per salvare la modifica delle definizioni-------------------------------------------------------------------
        {
            bool rimosse = false;                                                       //creo una variabile booleana per determinare se una o più definizioni sono state rimosse
                                                                                        //      per qualche motivo
            foreach(string s in nodo.Definizioni)                                       
            {
                if(s.Trim() == "")                                                      //verifico se una definizione è vuota
                {
                    rimosse = true;                                                     //salvo il fatto che una definizione è stata rimossa
                    nodo.Definizioni.Remove(s);                                         //rimuovo la definizione in causa
                }
            }                                                                           //ripeto per tutte le definizioni
            if(nodo.Definizioni.Count == 0)                                             //verifico se sono state rimosse tutte le definizioni
            {
                alberello.eliminaParola(nodo.Sezione);                                  //elimino la paola dall'albero
            }
            if (rimosse)                                                                //verifico se ci sono state definizione rimosse
                MessageBox.Show("Alcune definizioni sono state rimosse perchè vuote");  //invio un feedback sulla rimozione delle definizioni all'utente
            alberello.AggiungineUno(nodo);                                              //salvo il nodo, che si sostituirà a quello precedente
            MessageBox.Show("Le modifiche sono state salvate, ora puoi tornare alla " + //invio una conferma della modifica
                "schermata precedete");
        }//--------------------------------------------------------------------------------------------------------------------------------------------------------------------------

        private void button12_Click(object sender, EventArgs e) //bottone indietro pannel2 (modifica definizioni)--------------------------------------------------------------------
        {
            panel2.Visible = false;                                                     //torno alla schermata dove visualizzo de definizioni
            panel1.Visible = false;                                                     //torno al menù principale
        }//--------------------------------------------------------------------------------------------------------------------------------------------------------------------------

        private void button20_Click(object sender, EventArgs e) //bottone elimina parola panel2--------------------------------------------------------------------------------------
        {
            alberello.eliminaParola(nodo.Sezione);                                      //elimina la parola dall'albero
            panel2.Visible = false;                                                     //torna alla 
            panel1.Visible = false;                                                     //torna al menù principale
        }//--------------------------------------------------------------------------------------------------------------------------------------------------------------------------

        private void button19_Click(object sender, EventArgs e) //bottone elimina definizione panel2---------------------------------------------------------------------------------
        {
            nodo.Definizioni.RemoveAt(tag);                                             //elimina la definizione dalla 
            if(nodo.Definizioni.Count == 0)                                             //controllo se ho eliminato tutte le definizioni
            {
                panel2.Visible = false;                                                 //torna alla 
                panel1.Visible = false;                                                 //torna al menù principale
            }
            textBox3.Text = nodo.Definizioni[0];                                        //faccio visualizzare la prima definizione della parola
            tag = 0;                                                                    //porto il tag alla posizione della definizione
        }//--------------------------------------------------------------------------------------------------------------------------------------------------------------------------

        private void button13_Click(object sender, EventArgs e) //bottone aggiungi panel2--------------------------------------------------------------------------------------------
        {
            if (textBox3.Text.Trim == "")                                               //verifico se il testo che è stato inserito è valido 
            {
                MessageBox.Show("Inserire una traduzione valida");                      //invio un messaggio d'errore dicendo che il testo inserito non è valido
                return;                                                                 //blocco l'esecuzione della funzione
            }
            nodo.Definizioni.Add(textBox3.Text);                                        //salvo nel nodo la definizione che ho appena aggiunto
            alberello.AggiungineUno(nodo);                                              //salvo il nodo aggiornato nell'albero
        }//--------------------------------------------------------------------------------------------------------------------------------------------------------------------------

        private void button18_Click(object sender, EventArgs e) //bottone indietro panel3--------------------------------------------------------------------------------------------
        {
            panel3.Visible = false;                                                     //nascondo ila pannello 3 (aggiunta di una parola)
        }//--------------------------------------------------------------------------------------------------------------------------------------------------------------------------

        private void button15_Click(object sender, EventArgs e) //bottone salva panel3-----------------------------------------------------------------------------------------------
        {
            if(textBox5.Text.Trim != "" && textBox4.Text.Trim != "")                    //verifico che i campi siano stati compilati adeguatamente
            {
                Nodo n = new Nodo(textBox5.Text, true);                                 //creo il mio nodo di appoggio
                n.AggiungiDefinizione(textBox4.Text);                                   //riempio il mio nodo di appoggio con la sua prima definizione
                alberello.AggiungineUno(n);                                             //aggiungo il nodo all'alabero
                textBox4.Text = "";                                                     //resetto il campo della definizione
                textBox5.Text = "";                                                     //resetto il campo del titolo
            }
            else
            {
                MessageBox.Show("Verifica di aver compilato correttamente " +           //invio una segnalazione che non è stato possibile aggiungere la parola in quanto i campi
                    "tutti i campi")                                                    //      non erano adeguatamente adempiti
            }
        }//--------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    }
}
